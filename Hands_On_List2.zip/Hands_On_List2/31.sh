#!/bin/bash


# /*
# ============================================================================================
# File Name : 31.sh
# Author : Naval Kishore Singh Bisht
# Roll No : MT2024099
# Description : 31. Write a program to create a semaphore and initialize value to the semaphore.
                # a. create a binary semaphore
                # b. create a counting semaphore
# Data : 19/09/2024
# ============================================================================================
# */

touch file31
chmod 666 file31
