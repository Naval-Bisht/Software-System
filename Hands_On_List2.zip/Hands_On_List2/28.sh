#!/bin/bash


# /*
# ============================================================================================
# File Name : 28.c
# Author : Naval Kishore Singh Bisht
# Roll No : MT2024099
# Description : 28. Write a program to change the exiting message queue permission. (use msqid_ds structure)
# Data : 19/09/2024
# ============================================================================================
# */

touch file28
chmod 666 file28