#!/bin/bash


# /*
# ============================================================================================
# File Name : 24.sh
# Author : Naval Kishore Singh Bisht
# Roll No : MT2024099
# Description : 24. Write a program to create a message queue and print the key and message queue id.
# Data : 19/09/2024
# ============================================================================================
# */

touch progfile24
chmod 644 progfile24
