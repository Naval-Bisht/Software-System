#!/bin/bash


# /*
# ============================================================================================
# File Name : 27.sh
# Author : Naval Kishore Singh Bisht
# Roll No : MT2024099
# Description : 27. Write a program to receive messages from the message queue.
#                     a. with 0 as a flag
#                     b. with IPC_NOWAIT as a flag
# Data : 19/09/2024
# ============================================================================================
# */

touch file27
chmod 644 file27
