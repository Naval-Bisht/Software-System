#!/bin/bash

# /*
# ============================================================================================
# File Name : 26.sh
# Author : Naval Kishore Singh Bisht
# Roll No : MT2024099
# Description : 26. Write a program to send messages to the message queue. Check $ipcs -q
# Data : 19/09/2024
# ============================================================================================
# */


touch file26
chmod 644 file26
