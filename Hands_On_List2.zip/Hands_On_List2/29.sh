#!/bin/bash

# /*
# ============================================================================================
# File Name : 29.sh
# Author : Naval Kishore Singh Bisht
# Roll No : MT2024099
# Description : 29. Write a program to remove the message queue.
# Data : 19/09/2024
# ============================================================================================
# */

touch file29
chmod 666 file29